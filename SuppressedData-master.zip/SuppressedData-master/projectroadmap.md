* 1. download arcgis- just obtained license - DONE
* 2. find census data to create geodatabase with - DONE
* 3. create geodatabase in arcmap/catalog - DONE (reusing geodatabase created in my Direct Applied Research course.)
* 4. create layout in ArcMap- cannot insert layout items in arcmap with python alone
* 5. using code as an example/template from original rendition from which this repository was forked from. - DONE
* 6. apply found code to my own - DONE
* 7. create an input function
* 8. create a function that clips an inputted attribute (if the data is suppressed in that attribute) from a shapefile table and creates a new shapefile from it
* 9. create function that uploads to arcmap? N/A 
* 10. insert new shapefile into layout
